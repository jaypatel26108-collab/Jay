// app/api/webhook/route.js
import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { adminDb } from "@/lib/firebaseAdmin";
import { generateMigrationReport } from "@/lib/generateReport";

export const config = { api: { bodyParser: false } };

export async function POST(req) {
  const body = await req.text();
  const sig = req.headers.get("stripe-signature");

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature error:", err.message);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const { userId, userEmail, pendingReportId } = session.metadata;

    try {
      // Get the stored profile data
      const pendingDoc = await adminDb.collection("pendingReports").doc(pendingReportId).get();
      if (!pendingDoc.exists) {
        console.error("Pending report not found:", pendingReportId);
        return NextResponse.json({ error: "Pending report not found" }, { status: 404 });
      }

      const { profileData } = pendingDoc.data();

      // Record payment
      const paymentRef = await adminDb.collection("payments").add({
        userId,
        userEmail,
        stripeSessionId: session.id,
        amount: session.amount_total,
        currency: session.currency,
        status: "paid",
        reportGenerated: false,
        createdAt: new Date().toISOString(),
      });

      // Generate paid report immediately
      const report = await generateMigrationReport(profileData, true);

      // Save report
      const reportRef = await adminDb.collection("reports").add({
        userId,
        userEmail,
        profileData,
        report,
        isPaid: true,
        createdAt: new Date().toISOString(),
        paymentId: paymentRef.id,
        stripeSessionId: session.id,
      });

      // Mark payment as used
      await adminDb.collection("payments").doc(paymentRef.id).update({
        reportGenerated: true,
        reportId: reportRef.id,
      });

      // Clean up pending
      await adminDb.collection("pendingReports").doc(pendingReportId).delete();

      console.log("Paid report generated:", reportRef.id, "for user:", userId);
    } catch (err) {
      console.error("Webhook processing error:", err);
      return NextResponse.json({ error: "Processing failed" }, { status: 500 });
    }
  }

  return NextResponse.json({ received: true });
}
