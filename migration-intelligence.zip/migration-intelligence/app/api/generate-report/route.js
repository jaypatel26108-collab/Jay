// app/api/generate-report/route.js
import { NextResponse } from "next/server";
import { generateMigrationReport } from "@/lib/generateReport";
import { adminDb } from "@/lib/firebaseAdmin";

export async function POST(req) {
  try {
    const { profileData, isPaid, userId } = await req.json();

    if (!profileData) {
      return NextResponse.json({ error: "No profile data provided" }, { status: 400 });
    }

    // Paid reports require authenticated userId and a verified payment
    if (isPaid) {
      if (!userId) {
        return NextResponse.json({ error: "Authentication required for paid reports" }, { status: 401 });
      }
      // Verify payment record exists in Firestore
      const paymentDoc = await adminDb
        .collection("payments")
        .where("userId", "==", userId)
        .where("status", "==", "paid")
        .where("reportGenerated", "==", false)
        .limit(1)
        .get();

      if (paymentDoc.empty) {
        return NextResponse.json({ error: "No valid payment found" }, { status: 403 });
      }
    }

    const report = await generateMigrationReport(profileData, isPaid);

    // Save paid report to Firestore
    if (isPaid && userId) {
      const paymentSnap = await adminDb
        .collection("payments")
        .where("userId", "==", userId)
        .where("status", "==", "paid")
        .where("reportGenerated", "==", false)
        .limit(1)
        .get();

      const paymentId = paymentSnap.docs[0]?.id;

      const reportRef = await adminDb.collection("reports").add({
        userId,
        profileData,
        report,
        isPaid: true,
        createdAt: new Date().toISOString(),
        paymentId: paymentId || null,
      });

      // Mark payment as used
      if (paymentId) {
        await adminDb.collection("payments").doc(paymentId).update({
          reportGenerated: true,
          reportId: reportRef.id,
        });
      }

      return NextResponse.json({ report, reportId: reportRef.id });
    }

    return NextResponse.json({ report });
  } catch (err) {
    console.error("Report generation error:", err);
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 });
  }
}
