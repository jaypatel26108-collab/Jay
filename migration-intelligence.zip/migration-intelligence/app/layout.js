// app/layout.js
import { Toaster } from "react-hot-toast";
import "./globals.css";

export const metadata = {
  title: "Migration Intelligence — Australia 2026",
  description: "AI-powered strategic migration analysis for Australia. Personalized visa pathway, points optimization, skill assessment, and PR roadmap.",
  keywords: "Australia migration, skilled visa, 189 visa, 190 visa, 491 visa, PR pathway, migration agent",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet" />
      </head>
      <body>
        <Toaster position="top-center" toastOptions={{ style: { fontFamily: "DM Sans, sans-serif", fontSize: "0.875rem" } }} />
        {children}
      </body>
    </html>
  );
}
