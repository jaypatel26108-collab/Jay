// components/AuthModal.js
"use client";
import { signInWithPopup } from "firebase/auth";
import { auth, googleProvider } from "@/lib/firebase";
import toast from "react-hot-toast";

export default function AuthModal({ onClose, onSuccess, message }) {
  const handleGoogleSignIn = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      onSuccess(result.user);
      onClose();
    } catch (err) {
      console.error(err);
      toast.error("Sign-in failed. Please try again.");
    }
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(15,33,55,0.6)",
      display: "flex", alignItems: "center", justifyContent: "center",
      zIndex: 1000, backdropFilter: "blur(4px)",
    }} onClick={onClose}>
      <div style={{
        background: "#fff", borderRadius: 16, padding: "2.5rem 2rem",
        width: "100%", maxWidth: 420, textAlign: "center",
        boxShadow: "0 20px 60px rgba(0,0,0,0.15)",
      }} onClick={e => e.stopPropagation()}>
        <div style={{
          width: 48, height: 48, background: "linear-gradient(135deg, #1a56db, #0ea5e9)",
          borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center",
          margin: "0 auto 1.2rem",
        }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/>
            <path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
          </svg>
        </div>
        <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.4rem", color: "#0f2137", marginBottom: "0.5rem" }}>
          Sign in to Access Your Report
        </h2>
        <p style={{ color: "#64748b", fontSize: "0.88rem", lineHeight: 1.7, marginBottom: "1.8rem" }}>
          {message || "Create a free account to save and access your paid migration report anytime."}
        </p>
        <button onClick={handleGoogleSignIn} style={{
          width: "100%", padding: "0.8rem 1.5rem",
          border: "1.5px solid #e2e8f0", borderRadius: 10,
          background: "#fff", color: "#0f2137",
          fontSize: "0.92rem", fontWeight: 600,
          cursor: "pointer", display: "flex", alignItems: "center",
          justifyContent: "center", gap: "0.75rem",
          transition: "box-shadow 0.2s",
        }}>
          <svg width="20" height="20" viewBox="0 0 24 24">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          Continue with Google
        </button>
        <p style={{ fontSize: "0.73rem", color: "#94a3b8", marginTop: "1.2rem", lineHeight: 1.6 }}>
          Your data is used solely to generate your migration report. We never share your information.
        </p>
      </div>
    </div>
  );
}
