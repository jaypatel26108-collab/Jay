"use client";
import { useState, useEffect } from "react";
import { onAuthStateChanged, signOut, signInWithPopup } from "firebase/auth";
import { collection, query, where, getDocs, doc, getDoc, orderBy } from "firebase/firestore";
import { auth, db, googleProvider } from "@/lib/firebase";
import ReactMarkdown from "react-markdown";
import Nav from "@/components/Nav";
import AuthModal from "@/components/AuthModal";
import toast from "react-hot-toast";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

function DashboardContent() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const params = useSearchParams();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setLoading(false);
      if (u) await loadReports(u);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (params.get("payment") === "success") {
      toast.success("Payment successful! Your premium report is being generated and will appear below shortly.");
      // Poll for new reports for 30s
      let attempts = 0;
      const iv = setInterval(async () => {
        if (auth.currentUser) await loadReports(auth.currentUser);
        if (++attempts > 10) clearInterval(iv);
      }, 3000);
    }
  }, [params]);

  const loadReports = async (u) => {
    try {
      const q = query(
        collection(db, "reports"),
        where("userId", "==", u.uid),
        orderBy("createdAt", "desc")
      );
      const snap = await getDocs(q);
      setReports(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) {
      console.error("Load reports error:", e);
    }
  };

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "80vh" }}>
      <div style={{ width: 40, height: 40, border: "3px solid #e2e8f0", borderTop: "3px solid #1a56db", borderRadius: "50%", animation: "spin 1s linear infinite" }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  if (!user) return (
    <div style={{ minHeight: "100vh", background: "#f0f4f8", fontFamily: "'DM Sans',sans-serif" }}>
      <Nav user={null} onSignIn={() => setShowAuth(true)} />
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} onSuccess={async (u) => { setUser(u); await loadReports(u); }} message="Sign in to access your saved migration reports." />}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "80vh", textAlign: "center", padding: "2rem" }}>
        <div>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: "1.5rem", color: "#0f2137", marginBottom: "0.6rem" }}>Sign in to View Your Reports</h2>
          <p style={{ color: "#64748b", fontSize: "0.9rem", marginBottom: "1.5rem" }}>Access your saved premium migration reports anytime.</p>
          <button onClick={() => setShowAuth(true)} style={{ background: "linear-gradient(135deg,#1a56db,#0ea5e9)", color: "#fff", padding: "0.8rem 2rem", borderRadius: 9, border: "none", fontSize: "0.9rem", fontWeight: 600, cursor: "pointer" }}>Sign in with Google</button>
        </div>
      </div>
    </div>
  );

  // Show individual report
  if (selectedReport) return (
    <div style={{ minHeight: "100vh", background: "#f0f4f8", fontFamily: "'DM Sans',sans-serif" }}>
      <Nav user={user} onSignOut={() => signOut(auth)} />
      <div style={{ maxWidth: 740, margin: "0 auto", padding: "2rem 1.5rem 5rem" }}>
        <button onClick={() => setSelectedReport(null)} style={{ display: "flex", alignItems: "center", gap: "0.4rem", background: "none", border: "none", color: "#64748b", fontSize: "0.85rem", cursor: "pointer", marginBottom: "1.5rem" }}>
          ← Back to My Reports
        </button>
        <div style={{ background: "linear-gradient(135deg,#0f2137,#1a3a5c)", borderRadius: 16, padding: "1.8rem 2rem", marginBottom: "1.8rem", color: "#fff" }}>
          <p style={{ fontSize: "0.7rem", fontWeight: 600, color: "#93c5fd", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "0.4rem" }}>Premium Strategic Migration Roadmap</p>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: "1.4rem", marginBottom: "0.4rem" }}>{selectedReport.profileData?.fullName || "Your"} Migration Report</h1>
          <p style={{ color: "#64748b", fontSize: "0.78rem" }}>Generated {new Date(selectedReport.createdAt).toLocaleDateString("en-AU", { day: "numeric", month: "long", year: "numeric" })} · Migration Intelligence 2026</p>
        </div>
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: "2.2rem", boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
          <div className="report-body"><ReactMarkdown>{selectedReport.report}</ReactMarkdown></div>
        </div>
        <p style={{ fontSize: "0.75rem", color: "#94a3b8", textAlign: "center", marginTop: "1.5rem", lineHeight: 1.6 }}>
          This report is AI-generated for informational purposes only. Verify decisions with a registered Australian migration agent.
        </p>
      </div>
    </div>
  );

  // Dashboard list
  return (
    <div style={{ minHeight: "100vh", background: "#f0f4f8", fontFamily: "'DM Sans',sans-serif" }}>
      <Nav user={user} onSignOut={() => signOut(auth)} />
      <div style={{ maxWidth: 740, margin: "0 auto", padding: "2.5rem 1.5rem 5rem" }}>
        <div style={{ marginBottom: "2rem" }}>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: "1.6rem", color: "#0f2137", marginBottom: "0.3rem" }}>My Migration Reports</h1>
          <p style={{ color: "#64748b", fontSize: "0.88rem" }}>Signed in as {user.email}</p>
        </div>

        {reports.length === 0 ? (
          <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 16, padding: "3rem 2rem", textAlign: "center" }}>
            <p style={{ color: "#64748b", marginBottom: "0.5rem" }}>No premium reports yet.</p>
            <p style={{ color: "#94a3b8", fontSize: "0.85rem", marginBottom: "1.5rem" }}>Complete the assessment and upgrade to generate your premium report.</p>
            <a href="/" style={{ display: "inline-block", background: "linear-gradient(135deg,#1a56db,#0ea5e9)", color: "#fff", padding: "0.7rem 1.8rem", borderRadius: 9, fontSize: "0.9rem", fontWeight: 600, textDecoration: "none" }}>Start Assessment</a>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            {reports.map(r => (
              <div key={r.id} onClick={() => setSelectedReport(r)} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: "1.4rem 1.6rem", cursor: "pointer", transition: "box-shadow 0.2s", boxShadow: "0 1px 4px rgba(0,0,0,0.04)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <p style={{ fontWeight: 600, color: "#0f2137", marginBottom: "0.25rem", fontSize: "0.95rem" }}>{r.profileData?.fullName || "Migration Report"}</p>
                  <p style={{ fontSize: "0.78rem", color: "#94a3b8" }}>Generated {new Date(r.createdAt).toLocaleDateString("en-AU", { day: "numeric", month: "long", year: "numeric" })}</p>
                  <p style={{ fontSize: "0.75rem", color: "#1a56db", fontWeight: 600, marginTop: "0.25rem" }}>Premium Report</p>
                </div>
                <div style={{ color: "#94a3b8", fontSize: "1.1rem" }}>→</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Dashboard() {
  return (
    <Suspense>
      <DashboardContent />
    </Suspense>
  );
}
