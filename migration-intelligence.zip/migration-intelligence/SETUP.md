# Migration Intelligence — Setup & Deploy Guide

## What's included
- Next.js 14 app (Vercel-optimized)
- Google sign-in via Firebase Auth
- Gemini 1.5 Flash report generation
- Stripe checkout ($5.99 AUD, one-time)
- Firestore to save paid reports per user
- Free report (no login needed) → Upgrade to paid (login required)

---

## STEP 1 — Firebase Setup

1. Go to https://console.firebase.google.com
2. Create a new project → call it `migration-intelligence`
3. Enable **Authentication** → Sign-in method → **Google** → Enable
4. Enable **Firestore Database** → Start in production mode
5. Go to Project Settings → Your Apps → Add Web App → copy the config

### Firestore Security Rules
Go to Firestore → Rules tab → paste the contents of `firestore.rules` → Publish

### Firebase Admin SDK (for server)
1. Project Settings → Service Accounts → Generate New Private Key
2. Download the JSON file
3. You'll need: `project_id`, `client_email`, `private_key` from that file

---

## STEP 2 — Gemini API Key

1. Go to https://aistudio.google.com/app/apikey
2. Create an API key
3. Copy it → this is your `GEMINI_API_KEY`

---

## STEP 3 — Stripe Setup

1. Go to https://dashboard.stripe.com
2. Get your keys from Developers → API Keys:
   - **Publishable key** → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
   - **Secret key** → `STRIPE_SECRET_KEY`
3. For the webhook (after deploying to Vercel):
   - Stripe Dashboard → Developers → Webhooks → Add endpoint
   - URL: `https://your-app.vercel.app/api/webhook`
   - Events to listen for: `checkout.session.completed`
   - Copy the **Signing secret** → `STRIPE_WEBHOOK_SECRET`

---

## STEP 4 — Deploy to Vercel

### Option A: GitHub (Recommended)
```bash
# 1. Create a GitHub repo and push this project
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/migration-intelligence.git
git push -u origin main

# 2. Go to https://vercel.com → New Project → Import from GitHub
# 3. Add all environment variables (see below)
# 4. Deploy
```

### Option B: Vercel CLI
```bash
npm install -g vercel
vercel login
vercel --prod
```

---

## STEP 5 — Environment Variables in Vercel

Go to your Vercel project → Settings → Environment Variables → add each:

```
NEXT_PUBLIC_FIREBASE_API_KEY          = from Firebase web app config
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN      = your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID       = your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET   = your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID = from Firebase config
NEXT_PUBLIC_FIREBASE_APP_ID           = from Firebase config

FIREBASE_ADMIN_PROJECT_ID             = from service account JSON
FIREBASE_ADMIN_CLIENT_EMAIL           = from service account JSON
FIREBASE_ADMIN_PRIVATE_KEY            = from service account JSON (the full -----BEGIN PRIVATE KEY----- ... -----END PRIVATE KEY-----)

GEMINI_API_KEY                        = from Google AI Studio

NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY    = pk_live_... or pk_test_...
STRIPE_SECRET_KEY                     = sk_live_... or sk_test_...
STRIPE_WEBHOOK_SECRET                 = whsec_... (from Stripe webhook setup)

NEXT_PUBLIC_APP_URL                   = https://your-app.vercel.app
```

> ⚠️ For `FIREBASE_ADMIN_PRIVATE_KEY`: copy the entire key including the `-----BEGIN` and `-----END` lines. Vercel handles the `\n` characters automatically.

---

## STEP 6 — Add Authorized Domain in Firebase

1. Firebase Console → Authentication → Settings → Authorized domains
2. Add your Vercel domain: `your-app.vercel.app`

---

## STEP 7 — Test Locally

```bash
# Install dependencies
npm install

# Create .env.local from the example
cp .env.example .env.local
# Fill in all values in .env.local

# Run dev server
npm run dev
```

For local Stripe webhooks:
```bash
# Install Stripe CLI
stripe listen --forward-to localhost:3000/api/webhook
```

---

## Flow Summary

```
User fills 10-step form
         ↓
Free report generated (no login, no payment)
         ↓
User clicks "Upgrade — $5.99 AUD"
         ↓
If not logged in → Google sign-in modal
         ↓
Stripe Checkout ($5.99 AUD one-time)
         ↓
Stripe webhook fires → Gemini generates paid report → saved to Firestore
         ↓
User redirected to /dashboard → sees their report
         ↓
User can sign in anytime to re-access report
```

---

## Firestore Collections

| Collection | Purpose |
|---|---|
| `reports` | Saved paid reports (userId, report, profileData, createdAt) |
| `payments` | Payment records linked to Stripe sessions |
| `pendingReports` | Temporary profile data between checkout and webhook |

---

## Going Live Checklist

- [ ] Switch Stripe from test mode to live mode
- [ ] Update `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` and `STRIPE_SECRET_KEY` to live keys
- [ ] Create live Stripe webhook with your production URL
- [ ] Add custom domain in Vercel and Firebase authorized domains
- [ ] Test full flow end-to-end on production
