"use client";
import { useState, useEffect, useRef } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import Nav from "@/components/Nav";
import AuthModal from "@/components/AuthModal";
import ReactMarkdown from "react-markdown";
import toast from "react-hot-toast";

const STEPS = [
  "Basic Profile", "Visa Status", "Education", "English Language",
  "Employment History", "Spouse / Partner", "Health & Character",
  "Financial & Strategy", "Extra Questions", "Custom Questions",
];

// ─── Shared UI ───────────────────────────────────────────────────
const S = {
  input: { width: "100%", padding: "0.65rem 0.9rem", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: "0.9rem", color: "#0f2137", background: "#fff", outline: "none", boxSizing: "border-box", fontFamily: "inherit" },
  label: { display: "block", fontSize: "0.78rem", fontWeight: 600, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "0.35rem" },
};

function Field({ label, hint, children }) {
  return (
    <div style={{ marginBottom: "1.1rem" }}>
      <label style={S.label}>{label}</label>
      {hint && <p style={{ fontSize: "0.76rem", color: "#94a3b8", marginBottom: "0.3rem" }}>{hint}</p>}
      {children}
    </div>
  );
}
function Input({ value, onChange, placeholder, type = "text" }) {
  return <input type={type} value={value || ""} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={S.input} />;
}
function Sel({ value, onChange, options, placeholder }) {
  return (
    <select value={value || ""} onChange={e => onChange(e.target.value)} style={{ ...S.input, appearance: "none", backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E")`, backgroundRepeat: "no-repeat", backgroundPosition: "right 0.9rem center" }}>
      <option value="">{placeholder || "Select..."}</option>
      {options.map(o => <option key={o.v || o} value={o.v || o}>{o.l || o}</option>)}
    </select>
  );
}
function Textarea({ value, onChange, placeholder, rows = 3 }) {
  return <textarea value={value || ""} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={rows} style={{ ...S.input, resize: "vertical", lineHeight: 1.6 }} />;
}
function Radio({ value, onChange, options }) {
  return (
    <div style={{ display: "flex", gap: "0.6rem", flexWrap: "wrap" }}>
      {options.map(o => (
        <button key={o} type="button" onClick={() => onChange(o)} style={{ padding: "0.4rem 0.9rem", borderRadius: 6, border: `1.5px solid ${value === o ? "#1a56db" : "#e2e8f0"}`, background: value === o ? "#eff6ff" : "#fff", color: value === o ? "#1a56db" : "#64748b", fontSize: "0.83rem", fontWeight: value === o ? 600 : 400, cursor: "pointer" }}>
          {o}
        </button>
      ))}
    </div>
  );
}
function Grid2({ children }) {
  return <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>{children}</div>;
}
function SubCard({ title, children, onRemove }) {
  return (
    <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 10, padding: "1.2rem", marginBottom: "1rem", position: "relative" }}>
      <p style={{ fontWeight: 600, color: "#1a3a5c", marginBottom: "1rem", fontSize: "0.88rem" }}>{title}</p>
      {onRemove && <button type="button" onClick={onRemove} style={{ position: "absolute", top: "0.9rem", right: "0.9rem", background: "none", border: "none", cursor: "pointer", color: "#94a3b8", fontSize: "0.8rem" }}>Remove</button>}
      {children}
    </div>
  );
}
function AddBtn({ onClick, label }) {
  return <button type="button" onClick={onClick} style={{ padding: "0.45rem 1.1rem", borderRadius: 7, border: "1.5px dashed #cbd5e1", background: "transparent", color: "#64748b", fontSize: "0.83rem", cursor: "pointer" }}>{label}</button>;
}

// ─── Steps ────────────────────────────────────────────────────────
function Step1({ d, u }) {
  return <>
    <Field label="Full Name"><Input value={d.fullName} onChange={v => u("fullName", v)} placeholder="e.g. Aiden Sharma" /></Field>
    <Grid2>
      <Field label="Date of Birth"><Input type="date" value={d.dob} onChange={v => u("dob", v)} /></Field>
      <Field label="Gender"><Sel value={d.gender} onChange={v => u("gender", v)} options={["Male","Female","Non-binary","Prefer not to say"]} /></Field>
    </Grid2>
    <Grid2>
      <Field label="Relationship Status"><Sel value={d.relStatus} onChange={v => u("relStatus", v)} options={["Single","Married","De Facto","Divorced","Widowed"]} /></Field>
      <Field label="Nationality"><Input value={d.nationality} onChange={v => u("nationality", v)} placeholder="e.g. Indian" /></Field>
    </Grid2>
    <Field label="Current Country of Residence"><Input value={d.currentCountry} onChange={v => u("currentCountry", v)} placeholder="e.g. Australia" /></Field>
    <Field label="Australian Location" hint="Only if currently in Australia">
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: "0.6rem" }}>
        <Input value={d.suburb} onChange={v => u("suburb", v)} placeholder="Suburb" />
        <Sel value={d.state} onChange={v => u("state", v)} options={["NSW","VIC","QLD","SA","WA","TAS","NT","ACT"]} placeholder="State" />
        <Input value={d.postcode} onChange={v => u("postcode", v)} placeholder="Postcode" />
      </div>
    </Field>
  </>;
}

function Step2({ d, u }) {
  return <>
    <Field label="Current Visa Type"><Input value={d.visaType} onChange={v => u("visaType", v)} placeholder="e.g. Student 500, Skilled Work 482, Visitor 600..." /></Field>
    <Field label="Visa Expiry Date"><Input type="date" value={d.visaExpiry} onChange={v => u("visaExpiry", v)} /></Field>
    <Field label="Currently on Bridging Visa?"><Radio value={d.bridgingVisa} onChange={v => u("bridgingVisa", v)} options={["Yes","No"]} /></Field>
    {d.bridgingVisa === "Yes" && <Field label="Associated application"><Input value={d.bridgingAssociated} onChange={v => u("bridgingAssociated", v)} placeholder="e.g. Subclass 189 onshore application" /></Field>}
    <Field label="Any Australian visa refusals?"><Radio value={d.ausRefusals} onChange={v => u("ausRefusals", v)} options={["Yes","No"]} /></Field>
    {d.ausRefusals === "Yes" && <Field label="Details"><Textarea value={d.ausRefusalDetails} onChange={v => u("ausRefusalDetails", v)} placeholder="Describe circumstances briefly..." /></Field>}
    <Field label="Refusals from other countries?"><Radio value={d.otherRefusals} onChange={v => u("otherRefusals", v)} options={["Yes","No"]} /></Field>
    <Field label="Any visa cancellations or immigration bans?"><Radio value={d.cancellations} onChange={v => u("cancellations", v)} options={["Yes","No"]} /></Field>
    {d.cancellations === "Yes" && <Field label="Details"><Textarea value={d.cancellationDetails} onChange={v => u("cancellationDetails", v)} /></Field>}
  </>;
}

function Step3({ d, setD }) {
  const quals = d.qualifications || [{}];
  const upd = (i, k, v) => { const q=[...quals]; q[i]={...q[i],[k]:v}; setD(p=>({...p,qualifications:q})); };
  const add = () => setD(p => ({ ...p, qualifications: [...(p.qualifications||[{}]),{}] }));
  const rem = i => setD(p => ({ ...p, qualifications: quals.filter((_,j)=>j!==i) }));
  return <>
    {quals.map((q,i)=>(
      <SubCard key={i} title={`Qualification ${i+1}`} onRemove={quals.length>1?()=>rem(i):null}>
        <Grid2>
          <Field label="Qualification Name"><Input value={q.name} onChange={v=>upd(i,"name",v)} placeholder="e.g. Bachelor of IT" /></Field>
          <Field label="Field of Study"><Input value={q.field} onChange={v=>upd(i,"field",v)} placeholder="e.g. Computer Science" /></Field>
          <Field label="Institution"><Input value={q.institution} onChange={v=>upd(i,"institution",v)} placeholder="University / TAFE name" /></Field>
          <Field label="Country"><Input value={q.country} onChange={v=>upd(i,"country",v)} placeholder="e.g. Australia" /></Field>
        </Grid2>
        <Grid2>
          <Field label="Start Date"><Input type="month" value={q.start} onChange={v=>upd(i,"start",v)} /></Field>
          <Field label="End Date"><Input type="month" value={q.end} onChange={v=>upd(i,"end",v)} /></Field>
        </Grid2>
        <Field label="Status"><Radio value={q.status} onChange={v=>upd(i,"status",v)} options={["Completed","Ongoing"]} /></Field>
        <Field label="Delivery"><Radio value={q.delivery} onChange={v=>upd(i,"delivery",v)} options={["On-campus","Online","Mixed"]} /></Field>
        <Field label="Completed in Regional Australia?"><Radio value={q.regional} onChange={v=>upd(i,"regional",v)} options={["Yes","No"]} /></Field>
      </SubCard>
    ))}
    <AddBtn onClick={add} label="+ Add Another Qualification" />
  </>;
}

function Step4({ d, u }) {
  return <>
    <Field label="Have you completed an English test?"><Radio value={d.englishTested} onChange={v=>u("englishTested",v)} options={["Yes","No"]} /></Field>
    {d.englishTested==="Yes"&&<>
      <Grid2>
        <Field label="Test Type"><Sel value={d.englishTest} onChange={v=>u("englishTest",v)} options={["IELTS","PTE","TOEFL","Cambridge","OET"]} /></Field>
        <Field label="Test Date"><Input type="date" value={d.englishDate} onChange={v=>u("englishDate",v)} /></Field>
      </Grid2>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:"0.6rem"}}>
        {["Listening","Reading","Writing","Speaking"].map(s=>(
          <Field key={s} label={s}><Input value={d[s.toLowerCase()]} onChange={v=>u(s.toLowerCase(),v)} placeholder="Score" /></Field>
        ))}
      </div>
      <Field label="Overall Score"><Input value={d.englishOverall} onChange={v=>u("englishOverall",v)} placeholder="e.g. 7.5" /></Field>
    </>}
    {d.englishTested==="No"&&<Field label="Self-assessed level"><Sel value={d.englishSelfAssess} onChange={v=>u("englishSelfAssess",v)} options={["Basic","Competent","Proficient","Superior"]} /></Field>}
    <Field label="Willing to retake English exam?"><Radio value={d.retakeEnglish} onChange={v=>u("retakeEnglish",v)} options={["Yes","No","Maybe"]} /></Field>
  </>;
}

function Step5({ d, setD }) {
  const jobs = d.jobs||[{}];
  const upd=(i,k,v)=>{const j=[...jobs];j[i]={...j[i],[k]:v};setD(p=>({...p,jobs:j}));};
  const add=()=>setD(p=>({...p,jobs:[...(p.jobs||[{}]),{}]}));
  const rem=i=>setD(p=>({...p,jobs:jobs.filter((_,j)=>j!==i)}));
  return <>
    {jobs.map((j,i)=>(
      <SubCard key={i} title={`Employment ${i+1}`} onRemove={jobs.length>1?()=>rem(i):null}>
        <Grid2>
          <Field label="Job Title"><Input value={j.title} onChange={v=>upd(i,"title",v)} placeholder="e.g. Software Engineer" /></Field>
          <Field label="Employer Name"><Input value={j.employer} onChange={v=>upd(i,"employer",v)} placeholder="Company name" /></Field>
          <Field label="Industry"><Input value={j.industry} onChange={v=>upd(i,"industry",v)} placeholder="e.g. Information Technology" /></Field>
          <Field label="Country"><Input value={j.country} onChange={v=>upd(i,"country",v)} placeholder="e.g. Australia" /></Field>
        </Grid2>
        <Field label="Key Duties"><Textarea value={j.duties} onChange={v=>upd(i,"duties",v)} placeholder="Briefly describe your main responsibilities..." /></Field>
        <Grid2>
          <Field label="Start Date"><Input type="month" value={j.start} onChange={v=>upd(i,"start",v)} /></Field>
          <Field label="End Date (leave blank if current)"><Input type="month" value={j.end} onChange={v=>upd(i,"end",v)} /></Field>
        </Grid2>
        <Field label="Employment Type"><Radio value={j.type} onChange={v=>upd(i,"type",v)} options={["Full-time","Part-time","Casual"]} /></Field>
        <Grid2>
          <Field label="Avg Weekly Hours"><Input value={j.hours} onChange={v=>upd(i,"hours",v)} placeholder="e.g. 38" /></Field>
          <Field label="Salary (AUD)"><Input value={j.salary} onChange={v=>upd(i,"salary",v)} placeholder="e.g. $85,000–$100,000" /></Field>
        </Grid2>
        <Field label="Could this employer sponsor you?"><Radio value={j.canSponsor} onChange={v=>upd(i,"canSponsor",v)} options={["Yes","No","Unsure"]} /></Field>
      </SubCard>
    ))}
    <AddBtn onClick={add} label="+ Add Another Role" />
  </>;
}

function Step6({ d, u }) {
  const hasPartner=["Married","De Facto"].includes(d.relStatus);
  if(!hasPartner) return <div style={{textAlign:"center",padding:"2rem",color:"#94a3b8"}}><p>This section applies to married or de facto applicants only.</p><p style={{fontSize:"0.82rem",marginTop:"0.5rem"}}>Proceed to the next step.</p></div>;
  return <>
    <Field label="Partner currently"><Radio value={d.partnerLocation} onChange={v=>u("partnerLocation",v)} options={["Onshore (in Australia)","Offshore"]} /></Field>
    <Field label="Partner's current visa"><Input value={d.partnerVisa} onChange={v=>u("partnerVisa",v)} placeholder="e.g. Dependent on your visa / Own 500..." /></Field>
    <Field label="Partner's occupation"><Input value={d.partnerOccupation} onChange={v=>u("partnerOccupation",v)} placeholder="e.g. Registered Nurse" /></Field>
    <Field label="Partner's English level"><Sel value={d.partnerEnglish} onChange={v=>u("partnerEnglish",v)} options={["No test","Basic","Competent","Proficient","Superior","Has test scores"]} /></Field>
    <Field label="Partner's highest qualification"><Input value={d.partnerQual} onChange={v=>u("partnerQual",v)} placeholder="e.g. Bachelor of Nursing" /></Field>
    <Field label="Partner criminal history?"><Radio value={d.partnerCriminal} onChange={v=>u("partnerCriminal",v)} options={["Yes","No"]} /></Field>
    <Field label="Partner health conditions?"><Radio value={d.partnerHealth} onChange={v=>u("partnerHealth",v)} options={["Yes","No"]} /></Field>
  </>;
}

function Step7({ d, u }) {
  return <>
    <div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:8,padding:"0.85rem",marginBottom:"1.2rem"}}>
      <p style={{fontSize:"0.8rem",color:"#92400e",lineHeight:1.65}}>Character and health issues do not automatically prevent migration outcomes, but they can affect eligibility and require strategic handling. All information is used solely to generate your personalized strategy report.</p>
    </div>
    <Field label="Significant medical conditions?"><Radio value={d.medicalConditions} onChange={v=>u("medicalConditions",v)} options={["Yes","No"]} /></Field>
    {d.medicalConditions==="Yes"&&<Field label="Brief details (optional)"><Textarea value={d.medicalDetails} onChange={v=>u("medicalDetails",v)} placeholder="Not required in detail..." /></Field>}
    <Field label="Australian health insurance?"><Radio value={d.healthInsurance} onChange={v=>u("healthInsurance",v)} options={["OHSC","Medicare","No","N/A"]} /></Field>
    <Field label="Criminal convictions?"><Radio value={d.criminalConvictions} onChange={v=>u("criminalConvictions",v)} options={["Yes","No"]} /></Field>
    {d.criminalConvictions==="Yes"&&<Field label="Nature of conviction"><Textarea value={d.criminalDetails} onChange={v=>u("criminalDetails",v)} placeholder="Nature, date, outcome..." /></Field>}
    <Field label="Pending court matters?"><Radio value={d.pendingCourt} onChange={v=>u("pendingCourt",v)} options={["Yes","No"]} /></Field>
    <Field label="Police clearances available?"><Radio value={d.policeClearance} onChange={v=>u("policeClearance",v)} options={["Yes","No","In progress"]} /></Field>
  </>;
}

function Step8({ d, u }) {
  return <>
    <Field label="Budget for migration process"><Sel value={d.budget} onChange={v=>u("budget",v)} options={["Under $5,000","$5,000–$10,000","$10,000–$20,000","$20,000–$40,000","$40,000+"]} /></Field>
    <Field label="Willing to relocate regional?"><Radio value={d.regionalWilling} onChange={v=>u("regionalWilling",v)} options={["Yes","No","Maybe"]} /></Field>
    <Field label="Open to further study?"><Radio value={d.furtherStudy} onChange={v=>u("furtherStudy",v)} options={["Yes","No","Maybe"]} /></Field>
    <Field label="Open to employer sponsorship?"><Radio value={d.openSponsorship} onChange={v=>u("openSponsorship",v)} options={["Yes","No","Maybe"]} /></Field>
    <Field label="Open to temporary visa before PR?"><Radio value={d.tempBeforePR} onChange={v=>u("tempBeforePR",v)} options={["Yes","No","Maybe"]} /></Field>
    <Field label="Primary migration priority"><Sel value={d.priority} onChange={v=>u("priority",v)} options={["Fast PR","Stability & Security","Employer Sponsorship","Lowest Cost","Long-term Citizenship"]} /></Field>
  </>;
}

function Step9({ d, u }) {
  return <>
    <Field label="Relatives in Australia?"><Radio value={d.relativesAus} onChange={v=>u("relativesAus",v)} options={["Yes","No"]} /></Field>
    <Field label="Preferred state"><Sel value={d.statePreference} onChange={v=>u("statePreference",v)} options={["No preference","NSW","VIC","QLD","SA","WA","TAS","NT","ACT"]} /></Field>
    <Field label="Nominated occupation (if known)"><Input value={d.nominatedOccupation} onChange={v=>u("nominatedOccupation",v)} placeholder="e.g. Software Engineer (261313)" /></Field>
    <Field label="Current points estimate (if known)"><Input value={d.pointsEstimate} onChange={v=>u("pointsEstimate",v)} placeholder="e.g. 75 points" /></Field>
    <Field label="EOI submitted?"><Radio value={d.eoiSubmitted} onChange={v=>u("eoiSubmitted",v)} options={["Yes","No"]} /></Field>
    <Field label="Skill assessment completed?"><Radio value={d.skillAssessmentDone} onChange={v=>u("skillAssessmentDone",v)} options={["Yes","No","In progress"]} /></Field>
    <Field label="NAATI completed?"><Radio value={d.naati} onChange={v=>u("naati",v)} options={["Yes","No"]} /></Field>
    <Field label="Professional Year completed?"><Radio value={d.professionalYear} onChange={v=>u("professionalYear",v)} options={["Yes","No","In progress"]} /></Field>
    <Field label="Australian study requirement met?"><Radio value={d.ausStudyReq} onChange={v=>u("ausStudyReq",v)} options={["Yes","No","Partially"]} /></Field>
  </>;
}

function Step10({ d, setD }) {
  const qs=d.customQuestions||[""];
  const upd=(i,v)=>{const a=[...qs];a[i]=v;setD(p=>({...p,customQuestions:a}));};
  const add=()=>setD(p=>({...p,customQuestions:[...(p.customQuestions||[""]),""]}));
  return <>
    <p style={{color:"#64748b",fontSize:"0.88rem",lineHeight:1.7,marginBottom:"1.2rem"}}>Add up to 3 specific migration questions you want answered in your report. Our AI will address each one directly.</p>
    {qs.map((q,i)=>(<Field key={i} label={`Question ${i+1}`}><Textarea value={q} onChange={v=>upd(i,v)} placeholder="e.g. Can my occupation qualify under the 491 given my regional work experience?" /></Field>))}
    {qs.length<3&&<AddBtn onClick={add} label="+ Add Another Question" />}
  </>;
}

// ─── Main Page ────────────────────────────────────────────────────
export default function Home() {
  const [screen, setScreen]=useState("landing");
  const [step, setStep]=useState(0);
  const [form, setForm]=useState({});
  const [report, setReport]=useState("");
  const [loading, setLoading]=useState(false);
  const [loadMsg, setLoadMsg]=useState("Analysing your profile...");
  const [user, setUser]=useState(null);
  const [showAuth, setShowAuth]=useState(false);
  const [pendingPaid, setPendingPaid]=useState(false);
  const reportRef=useRef(null);

  const MSGS=["Analysing your profile...","Evaluating occupation competitiveness...","Assessing points trajectory...","Mapping visa pathways...","Calibrating risk analysis...","Finalising your roadmap..."];
  useEffect(()=>{
    if(!loading) return;
    let i=0;
    const iv=setInterval(()=>{i=(i+1)%MSGS.length;setLoadMsg(MSGS[i]);},2000);
    return ()=>clearInterval(iv);
  },[loading]);

  useEffect(()=>{
    const unsub=onAuthStateChanged(auth,u=>setUser(u));
    return unsub;
  },[]);

  // After sign-in, if they were trying to pay, redirect to checkout
  useEffect(()=>{
    if(user&&pendingPaid){setPendingPaid(false);handleCheckout(user);}
  },[user,pendingPaid]);

  const update=(k,v)=>setForm(p=>({...p,[k]:v}));

  const generateFreeReport=async()=>{
    setLoading(true);
    setScreen("generating");
    try{
      const res=await fetch("/api/generate-report",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({profileData:form,isPaid:false})});
      const data=await res.json();
      if(data.error) throw new Error(data.error);
      setReport(data.report);
      setScreen("report");
    }catch(e){
      toast.error("Report generation failed. Please try again.");
      setScreen("onboarding");
    }
    setLoading(false);
  };

  const handleUpgradeClick=()=>{
    if(!user){setShowAuth(true);setPendingPaid(true);}
    else{handleCheckout(user);}
  };

  const handleCheckout=async(loggedUser)=>{
    try{
      const res=await fetch("/api/create-checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:loggedUser.uid,userEmail:loggedUser.email,profileData:form})});
      const data=await res.json();
      if(data.url) window.location.href=data.url;
      else toast.error("Could not start checkout. Please try again.");
    }catch(e){
      toast.error("Checkout failed. Please try again.");
    }
  };

  const steps=[
    <Step1 d={form} u={update}/>,<Step2 d={form} u={update}/>,
    <Step3 d={form} setD={setForm}/>,<Step4 d={form} u={update}/>,
    <Step5 d={form} setD={setForm}/>,<Step6 d={form} u={update}/>,
    <Step7 d={form} u={update}/>,<Step8 d={form} u={update}/>,
    <Step9 d={form} u={update}/>,<Step10 d={form} setD={setForm}/>,
  ];

  const btn=(label,onClick,primary=true)=>(
    <button type="button" onClick={onClick} style={{padding:"0.65rem 1.8rem",borderRadius:9,border:primary?"none":"1px solid #e2e8f0",background:primary?"linear-gradient(135deg,#1a56db,#0ea5e9)":"#fff",color:primary?"#fff":"#64748b",fontSize:"0.9rem",fontWeight:600,cursor:"pointer",transition:"opacity 0.15s"}}>
      {label}
    </button>
  );

  // ── Landing ──
  if(screen==="landing") return(
    <div style={{minHeight:"100vh",background:"#f0f4f8",fontFamily:"'DM Sans',sans-serif"}}>
      <Nav user={user} onSignIn={()=>setShowAuth(true)} onSignOut={()=>signOut(auth)} />
      {showAuth&&<AuthModal onClose={()=>setShowAuth(false)} onSuccess={u=>setUser(u)} />}

      {/* Hero */}
      <div style={{background:"linear-gradient(160deg,#0f2137 0%,#1a3a5c 55%,#0f2137 100%)",padding:"5rem 1.5rem 4.5rem",textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,backgroundImage:"radial-gradient(circle at 25% 50%, rgba(26,86,219,0.15),transparent 50%),radial-gradient(circle at 75% 20%, rgba(14,165,233,0.1),transparent 40%)",pointerEvents:"none"}}/>
        <div style={{maxWidth:660,margin:"0 auto",position:"relative"}}>
          <div style={{display:"inline-block",background:"rgba(26,86,219,0.2)",border:"1px solid rgba(26,86,219,0.4)",borderRadius:20,padding:"0.3rem 0.9rem",fontSize:"0.72rem",fontWeight:600,color:"#93c5fd",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"1.3rem"}}>AI-Powered · Australia 2026</div>
          <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:"clamp(1.9rem,5vw,3rem)",fontWeight:700,color:"#fff",lineHeight:1.15,marginBottom:"1rem"}}>Australia Migration<br/><span style={{color:"#60a5fa"}}>Intelligence Platform</span></h1>
          <p style={{fontSize:"1rem",color:"#94a3b8",lineHeight:1.8,maxWidth:520,margin:"0 auto 2.2rem"}}>AI-powered strategic analysis built around your qualifications, work history, visa status, points profile, sponsorship potential, and long-term PR opportunities.</p>
          <button type="button" onClick={()=>setScreen("onboarding")} style={{background:"linear-gradient(135deg,#1a56db,#0ea5e9)",color:"#fff",padding:"0.9rem 2.4rem",borderRadius:10,border:"none",fontSize:"1rem",fontWeight:600,cursor:"pointer",boxShadow:"0 8px 24px rgba(26,86,219,0.35)"}}>Start Your Free Assessment</button>
          <p style={{fontSize:"0.75rem",color:"#4b6280",marginTop:"0.75rem"}}>No payment required to begin.</p>
        </div>
      </div>

      {/* Features */}
      <div style={{maxWidth:960,margin:"0 auto",padding:"3.5rem 1.5rem"}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:"1.2rem"}}>
          {[
            {icon:"🎯",t:"Points Optimization",d:"Identify every available point and close the gap to your target score."},
            {icon:"🗺",t:"Visa Pathway Ranking",d:"189, 190, 491, 482, 186 — ranked by your eligibility and competitiveness."},
            {icon:"⚖️",t:"Risk Assessment",d:"English, occupation competition, age, character — every risk rated and mitigated."},
            {icon:"📅",t:"12-Month Action Plan",d:"A concrete, month-by-month migration roadmap built around your timeline."},
          ].map((f,i)=>(
            <div key={i} style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:12,padding:"1.4rem",boxShadow:"0 1px 5px rgba(0,0,0,0.04)"}}>
              <div style={{fontSize:"1.4rem",marginBottom:"0.65rem"}}>{f.icon}</div>
              <h3 style={{fontWeight:600,color:"#0f2137",marginBottom:"0.35rem",fontSize:"0.92rem"}}>{f.t}</h3>
              <p style={{color:"#64748b",fontSize:"0.83rem",lineHeight:1.65}}>{f.d}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Pricing */}
      <div style={{maxWidth:680,margin:"0 auto 4rem",padding:"0 1.5rem"}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1.2rem"}}>
          <div style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:14,padding:"1.8rem"}}>
            <p style={{fontSize:"0.72rem",fontWeight:700,color:"#94a3b8",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"0.5rem"}}>Free</p>
            <p style={{fontSize:"1.8rem",fontWeight:700,color:"#0f2137",marginBottom:"1rem"}}>$0</p>
            {["Profile Summary","Competitiveness Rating","Gap Analysis"].map(f=><p key={f} style={{fontSize:"0.83rem",color:"#64748b",marginBottom:"0.4rem"}}>✓ {f}</p>)}
          </div>
          <div style={{background:"linear-gradient(135deg,#0f2137,#1a3a5c)",border:"none",borderRadius:14,padding:"1.8rem",color:"#fff"}}>
            <p style={{fontSize:"0.72rem",fontWeight:700,color:"#93c5fd",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"0.5rem"}}>Premium</p>
            <p style={{fontSize:"1.8rem",fontWeight:700,marginBottom:"1rem"}}>$5.99 <span style={{fontSize:"0.8rem",fontWeight:400,color:"#94a3b8"}}>AUD</span></p>
            {["All 10 Report Sections","Skill Assessment Strategy","12-Month Roadmap","Risk Analysis","Saved to Your Account"].map(f=><p key={f} style={{fontSize:"0.83rem",color:"#93c5fd",marginBottom:"0.4rem"}}>✓ {f}</p>)}
          </div>
        </div>
      </div>
    </div>
  );

  // ── Onboarding ──
  if(screen==="onboarding") return(
    <div style={{minHeight:"100vh",background:"#f0f4f8",fontFamily:"'DM Sans',sans-serif"}}>
      <Nav user={user} onSignIn={()=>setShowAuth(true)} onSignOut={()=>signOut(auth)} rightContent={<span style={{fontSize:"0.82rem",color:"#64748b"}}>Step {step+1}/{STEPS.length}</span>} />
      {showAuth&&<AuthModal onClose={()=>setShowAuth(false)} onSuccess={u=>setUser(u)} />}
      <div style={{maxWidth:660,margin:"0 auto",padding:"2rem 1.5rem 5rem"}}>
        {/* Progress */}
        <div style={{marginBottom:"2rem"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:"0.4rem"}}>
            <span style={{fontSize:"0.78rem",color:"#64748b",fontWeight:500}}>{STEPS[step]}</span>
            <span style={{fontSize:"0.78rem",color:"#94a3b8"}}>{Math.round(((step+1)/STEPS.length)*100)}%</span>
          </div>
          <div style={{height:4,background:"#e2e8f0",borderRadius:4}}>
            <div style={{height:"100%",width:`${((step+1)/STEPS.length)*100}%`,background:"linear-gradient(90deg,#1a56db,#0ea5e9)",borderRadius:4,transition:"width 0.4s ease"}}/>
          </div>
          <div style={{display:"flex",gap:"0.3rem",flexWrap:"wrap",marginTop:"0.75rem"}}>
            {STEPS.map((s,i)=>(
              <span key={i} style={{fontSize:"0.68rem",padding:"0.18rem 0.55rem",borderRadius:20,background:i<step?"#eff6ff":i===step?"#1a56db":"#f1f5f9",color:i<step?"#1a56db":i===step?"#fff":"#94a3b8",fontWeight:i<=step?600:400}}>{s}</span>
            ))}
          </div>
        </div>

        {/* Form card */}
        <div style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:16,padding:"2rem",boxShadow:"0 2px 12px rgba(0,0,0,0.05)",marginBottom:"1.5rem"}}>
          <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.3rem",color:"#0f2137",marginBottom:"0.3rem"}}>{STEPS[step]}</h2>
          <p style={{fontSize:"0.78rem",color:"#94a3b8",marginBottom:"1.5rem"}}>Accurate information produces a more precise and valuable analysis.</p>
          {steps[step]}
        </div>

        {/* Nav buttons */}
        <div style={{display:"flex",justifyContent:"space-between"}}>
          {btn(step===0?"Back to Home":"Previous",()=>step===0?setScreen("landing"):setStep(s=>s-1),false)}
          {step<STEPS.length-1
            ?btn("Continue",()=>setStep(s=>s+1))
            :btn("Generate Free Report",generateFreeReport)
          }
        </div>
      </div>
    </div>
  );

  // ── Generating ──
  if(screen==="generating") return(
    <div style={{minHeight:"100vh",background:"#f0f4f8",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'DM Sans',sans-serif"}}>
      <div style={{textAlign:"center",maxWidth:380,padding:"2rem"}}>
        <div style={{width:56,height:56,border:"3px solid #e2e8f0",borderTop:"3px solid #1a56db",borderRadius:"50%",animation:"spin 1s linear infinite",margin:"0 auto 1.8rem"}}/>
        <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.4rem",color:"#0f2137",marginBottom:"0.6rem"}}>Generating Your Report</h2>
        <p style={{color:"#64748b",fontSize:"0.88rem",animation:"pulse 2s ease-in-out infinite"}}>{loadMsg}</p>
        <p style={{color:"#94a3b8",fontSize:"0.78rem",marginTop:"1.2rem"}}>This typically takes 15–30 seconds</p>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}} @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}`}</style>
    </div>
  );

  // ── Report ──
  if(screen==="report") return(
    <div style={{minHeight:"100vh",background:"#f0f4f8",fontFamily:"'DM Sans',sans-serif"}}>
      <Nav user={user} onSignIn={()=>setShowAuth(true)} onSignOut={()=>signOut(auth)} rightContent={
        <button type="button" onClick={handleUpgradeClick} style={{background:"linear-gradient(135deg,#1a56db,#0ea5e9)",color:"#fff",padding:"0.38rem 1rem",borderRadius:7,border:"none",fontSize:"0.8rem",fontWeight:600,cursor:"pointer"}}>Upgrade — $5.99 AUD</button>
      }/>
      {showAuth&&<AuthModal onClose={()=>setShowAuth(false)} onSuccess={u=>{setUser(u);setPendingPaid(true);}} message="Sign in with Google to unlock and save your Premium Migration Report." />}

      <div style={{maxWidth:740,margin:"0 auto",padding:"2rem 1.5rem 5rem"}}>
        {/* Report header */}
        <div style={{background:"linear-gradient(135deg,#0f2137,#1a3a5c)",borderRadius:16,padding:"1.8rem 2rem",marginBottom:"1.8rem",color:"#fff"}}>
          <p style={{fontSize:"0.7rem",fontWeight:600,color:"#93c5fd",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"0.4rem"}}>Initial Migration Feasibility Assessment</p>
          <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.5rem",marginBottom:"0.4rem"}}>{form.fullName||"Your"} Migration Report</h1>
          <p style={{color:"#64748b",fontSize:"0.78rem"}}>Generated {new Date().toLocaleDateString("en-AU",{day:"numeric",month:"long",year:"numeric"})} · Migration Intelligence Platform 2026</p>
        </div>

        {/* Report body */}
        <div style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:16,padding:"2.2rem",boxShadow:"0 2px 12px rgba(0,0,0,0.04)",marginBottom:"1.8rem"}} ref={reportRef}>
          <div className="report-body"><ReactMarkdown>{report}</ReactMarkdown></div>
        </div>

        {/* Upgrade CTA */}
        <div style={{background:"linear-gradient(135deg,#0f2137,#1a3a5c)",borderRadius:16,padding:"2.2rem",textAlign:"center",color:"#fff"}}>
          <p style={{fontSize:"0.7rem",fontWeight:600,color:"#93c5fd",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"0.6rem"}}>Unlock Your Full Premium Report</p>
          <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:"1.4rem",marginBottom:"0.6rem"}}>Get the Complete Strategic Roadmap</h2>
          <p style={{color:"#94a3b8",fontSize:"0.85rem",lineHeight:1.7,maxWidth:460,margin:"0 auto 1.5rem"}}>Includes Skill Assessment Strategy, Sponsorship Opportunities, Regional PR Pathways, Risk Analysis, Points Optimization, 12-Month Action Plan, Cost Breakdown, and Personalized Strategic Recommendations — all saved to your account.</p>
          <button type="button" onClick={handleUpgradeClick} style={{background:"linear-gradient(135deg,#1a56db,#0ea5e9)",color:"#fff",padding:"0.85rem 2.2rem",borderRadius:10,border:"none",fontSize:"0.95rem",fontWeight:600,cursor:"pointer",boxShadow:"0 8px 24px rgba(26,86,219,0.3)"}}>Unlock Deep Report — $5.99 AUD</button>
          <p style={{fontSize:"0.72rem",color:"#4b6280",marginTop:"0.75rem"}}>One-time payment. Report saved to your account permanently.</p>
        </div>

        <div style={{textAlign:"center",marginTop:"1.5rem"}}>
          <button type="button" onClick={()=>{setScreen("landing");setForm({});setStep(0);setReport("");}} style={{background:"none",border:"none",color:"#94a3b8",fontSize:"0.82rem",cursor:"pointer"}}>Start a new assessment</button>
        </div>
      </div>
    </div>
  );

  return null;
}
