// components/Nav.js
"use client";
import { useRouter } from "next/navigation";

export default function Nav({ user, onSignIn, onSignOut, rightContent }) {
  return (
    <nav style={{
      background: "#fff",
      borderBottom: "1px solid #e2e8f0",
      padding: "0 1.5rem",
      height: 60,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>
      <a href="/" style={{ display: "flex", alignItems: "center", gap: "0.5rem", textDecoration: "none" }}>
        <span style={{
          width: 30, height: 30,
          background: "linear-gradient(135deg, #1a56db, #0ea5e9)",
          borderRadius: 7,
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0,
        }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/>
            <path d="M2 17l10 5 10-5"/>
            <path d="M2 12l10 5 10-5"/>
          </svg>
        </span>
        <span style={{ fontSize: "0.95rem", fontWeight: 700, color: "#0f2137", letterSpacing: "-0.01em" }}>
          Migration<span style={{ color: "#1a56db" }}>Intelligence</span>
        </span>
      </a>

      <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
        {rightContent}
        {user ? (
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
            <span style={{ fontSize: "0.8rem", color: "#64748b", maxWidth: 180, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.email}</span>
            <a href="/dashboard" style={{ fontSize: "0.82rem", color: "#1a56db", fontWeight: 600, textDecoration: "none" }}>My Reports</a>
            <button onClick={onSignOut} style={{ fontSize: "0.78rem", color: "#94a3b8", background: "none", border: "none", cursor: "pointer", padding: "0.3rem 0.6rem" }}>Sign out</button>
          </div>
        ) : (
          onSignIn && (
            <button onClick={onSignIn} style={{
              padding: "0.4rem 1rem",
              borderRadius: "7px",
              border: "1px solid #e2e8f0",
              background: "#fff",
              color: "#0f2137",
              fontSize: "0.82rem",
              fontWeight: 600,
              cursor: "pointer",
            }}>Sign in</button>
          )
        )}
      </div>
    </nav>
  );
}
