// app/api/create-checkout/route.js
import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { adminDb } from "@/lib/firebaseAdmin";

export async function POST(req) {
  try {
    const { userId, userEmail, profileData } = await req.json();

    if (!userId || !userEmail) {
      return NextResponse.json({ error: "User must be logged in" }, { status: 401 });
    }

    // Store profile temporarily so we can retrieve after payment
    const pendingRef = await adminDb.collection("pendingReports").add({
      userId,
      userEmail,
      profileData,
      createdAt: new Date().toISOString(),
    });

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      customer_email: userEmail,
      line_items: [
        {
          price_data: {
            currency: "aud",
            unit_amount: 599, // $5.99 AUD in cents
            product_data: {
              name: "Migration Intelligence — Premium Deep Report",
              description: "Full strategic migration roadmap: 10 sections including Skill Assessment, Risk Analysis, 12-Month Action Plan, and Personalized Recommendations.",
              images: [],
            },
          },
          quantity: 1,
        },
      ],
      metadata: {
        userId,
        userEmail,
        pendingReportId: pendingRef.id,
      },
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}?payment=cancelled`,
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    console.error("Stripe checkout error:", err);
    return NextResponse.json({ error: "Failed to create checkout session" }, { status: 500 });
  }
}
